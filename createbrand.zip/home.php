<?php require_once "include/header.php"; ?>
<link rel="stylesheet" href="assets/css/index.css">
<?php require_once "include/headerM.php";
include_once("assets/php/function.php");
$conn = new fun();
?>
 <?php require_once "include/slider.php"; ?>
 <?php require_once "include/about.php"; ?>
 <?php require_once "include/service_slider.php"; ?>
 <?php require_once "include/team_slider.php"; ?>
 <?php require_once "include/work_slider.php"; ?>
 <?php require_once "include/last_five_blog.php"; ?>
 <?php require_once "include/count_w.php"; ?>  


<?php require_once "include/footer.php"; ?>