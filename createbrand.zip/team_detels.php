<?php require_once "include/header.php"; ?>
<link rel="stylesheet" href="assets/css/team-details.css">
<?php require_once "include/headerM.php";
$conn = new fun(); ?>

<div id="team_details">
    <div class="container">
        <div class="row">
    <div class="image">
    <img src="https://assets.toptal.io/images?url=https%3A%2F%2Fbs-uploads.toptal.io%2Fblackfish-uploads%2Ftalent%2Fprofile%2Fpicture_file%2Fpicture%2F1065667%2Fhuge_90fb7631e5d3f62d179fe9ca40317478-46da0068435556b45ed22930150aaf95.jpg&width=524" alt="">
    </div>
    <div class="text">
     <h2>Anuar Heberlein</h2>
     <h4>Web Designer And Developer</h4>
    </div>
        </div>
    </div>
</div>

<?php include 'include/footer.php' ?>