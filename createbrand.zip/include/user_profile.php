<?php

header("location:../user_profile.php")

?>