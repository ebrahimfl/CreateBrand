<link rel="stylesheet" href="assets/css/service-details.css">
<div class="container" id="service-details">
<div class="review">
            <h2>This Service Review </h2>
            <div class="row">
                <div class="card">
                    <div class="img">
                        <img src="assets/images/portrait-white-man-isolated_53876-40306.avif" alt="">
                    </div>
                    <div class="review-star-icons">
                        <img src="assets/icons/star-review-1.png" alt="">
                        <img src="assets/icons/star-review-1.png" alt="">
                        <img src="assets/icons/star-review-1.png" alt="">
                        <img src="assets/icons/star-review-1.png" alt="">
                        <img src="assets/icons/star-review-0.png" alt="">
                    </div>
                    <h3>Super customer service!</h3>
                    <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quibusdam, adipisci alias? Rem harum a architecto animi tempora ducimus eos officiis incidunt fugiat quidem atque ipsum, unde, inventore nihil porro eius.</p>
                </div>
                <div class="card">
                    <div class="img">
                        <img src="assets/images/portrait-white-man-isolated_53876-40306.avif" alt="">
                    </div>
                    <div class="review-star-icons">
                        <img src="assets/icons/star-review-1.png" alt="">
                        <img src="assets/icons/star-review-1.png" alt="">
                        <img src="assets/icons/star-review-1.png" alt="">
                        <img src="assets/icons/star-review-1.png" alt="">
                        <img src="assets/icons/star-review-0.png" alt="">
                    </div>
                    <h3>Super customer service!</h3>
                    <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quibusdam, adipisci alias? Rem harum a architecto animi tempora ducimus eos officiis incidunt fugiat quidem atque ipsum, unde, inventore nihil porro eius.</p>
                </div>
                <div class="card">
                    <div class="img">
                        <img src="assets/images/portrait-white-man-isolated_53876-40306.avif" alt="">
                    </div>
                    <div class="review-star-icons">
                        <img src="assets/icons/star-review-1.png" alt="">
                        <img src="assets/icons/star-review-1.png" alt="">
                        <img src="assets/icons/star-review-1.png" alt="">
                        <img src="assets/icons/star-review-1.png" alt="">
                        <img src="assets/icons/star-review-0.png" alt="">
                    </div>
                    <h3>Super customer service!</h3>
                    <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quibusdam, adipisci alias? Rem harum a architecto animi tempora ducimus eos officiis incidunt fugiat quidem atque ipsum, unde, inventore nihil porro eius.</p>
                </div>
            </div>

        </div>
</div>