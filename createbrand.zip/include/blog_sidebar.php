<div class="sidebar">

    <div class="recent_post">
        <h4>Resent Post</h4>
        <a href="">
            <div class="card">
                <img src="assets/images/card-img.png" alt="">

                <div class="texts">
                    <h5>7 Content marketing strategies for your online shop </h5>
                    <p>11 March 2023</p>
                </div>
            </div>
        </a>

        <a href="">
            <div class="card">
                <img src="assets/images/card-img.png" alt="">
                <div class="texts">
                    <h5>7 Content marketing strategies for your online shop </h5>
                    <p>11 March 2023</p>
                </div>
            </div>
        </a>
        <a href="">
            <div class="card">
                <img src="assets/images/card-img.png" alt="">

                <div class="texts">
                    <h5>7 Content marketing strategies for your online shop </h5>
                    <p>11 March 2023</p>
                </div>
            </div>
        </a>
        <a href="">
            <div class="card">
                <img src="assets/images/card-img.png" alt="">

                <div class="texts">
                    <h5>7 Content marketing strategies for your online shop </h5>
                    <p>11 March 2023</p>
                </div>
            </div>
        </a>
        <a href="">
            <div class="card">
                <img src="assets/images/card-img.png" alt="">

                <div class="texts">
                    <h5>7 Content marketing strategies for your online shop </h5>
                    <p>11 March 2023</p>
                </div>
            </div>
        </a>

    </div>
    <!-- <div class="category">
        <div class="row">
            <h4>Category</h4>

            <a href="?category=">
                <div class="card">
                </div>
            </a>
        </div>
    </div> -->
    <!-- <div class="social_link">
        <h4>Social Networks</h4>
        <div class="card">
            <div class="card-body">
                <a href="" target="_blank">
                    <div class="facebook"><img src="assets/icons/facebook.svg" alt=""></div> Facebook
                </a>
                <a href="" target="_blank">
                    <div class="instagram"><img src="assets/icons/instagram.svg" alt=""></div> Instagram
                </a>
            </div>
            <div class="card-body">
                <a href="" target="_blank">
                    <div class="linkdin"><img src="assets/icons/linkdin.svg" alt=""></div>Linkdin
                </a>
                <a href="" target="_blank">
                    <div class="twitter"><img src="assets/icons/twitter.svg" alt=""></div>Twitter
                </a>
            </div>
        </div>
    </div> -->
    <div class="hire_developer">
        <div class="text-for-hire">
            <h4>Hire Developer</h4>
        </div>
        <div class="main-developer">
            <img src="assets/images/blog/8629.jpg" alt="">
            <h4 class="name" >name </h4>
            <div class="skills-developer">
            <h5>skills</h5>
            <h5>skills</h5>
            <h5>skills</h5>
            <h5>skills</h5>

            </div>
            <h5>skills</h5>
            <div class="hire-btn">
                <a href="#">Hire Now </a>
            </div>
        </div>

    </div>
    <div class="pricing_sidebar">
        <div class="text-pricing_sidebar">
            <h4>Order Now </h4>
        </div>
        <div class="main-pricing">
            <div class="stone">
                <h4>stone</h4>
                <h4>Price : $54</h4>
                <div class="order-btn">
                    <a href="#">Order Now </a>
                </div>
            </div>
            <div class="silver">
            <h4>Silver</h4>
                <h4>Price : $54</h4>
                <div class="order-btn">
                    <a href="#">Order Now </a>
                </div>
            </div>
            <div class="gold">
            <h4>Gold</h4>
                <h4>Price : $54</h4>
                <div class="order-btn">
                    <a href="#">Order Now </a>
                </div>
            </div>
        </div>

    </div>
</div>