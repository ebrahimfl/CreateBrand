        
<link rel="stylesheet" href="assets/css/about.css">
<section id="about">      
    <div class="container">
        <div class="slider">
            <div class="card">
                <img src="assets/images/1.jpg" alt="" class="card_img">
                <h4>Redwan Hussain Shawon</h4>
                <p>Full-Stack Developer</p>
                <img src="assets/images/logo-01.svg" style="width: 70px;height:80px;margin-top:10px" alt="" class='logo'>
            </div>
            
        
            <div class="img">
                <img src="assets/images/slider/about-slider-1.svg" alt="" style='height:100%'>
            </div>
            <div class="img">
                <img src="assets/images/slider/about-slider-2.svg" alt="">
            </div>
            <div class="img">
                <img src="assets/images/slider/about-slider-3.svg" alt="">
            </div>
        </div>
    </div>
</section>