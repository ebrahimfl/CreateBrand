<link rel="stylesheet" href="assets/css/footer_pricing.css">
<!-- pricing area  -->


<section id="pricing" class="pricing">
    <div class="main-text">
        <span>Negotiable price</span>
        <h3>Price</h3>
    </div>
    <div class="section-pricing">
        <div class="pricing-box">
        <div class="box-img">
                <img src="assets/images/cross right icon/iron.jpg" alt="">
            </div>
            <h3>Stone </h3>
            <h2>Price <span>198.23/-</span></h2>
            <p> <img src="assets/images/cross right icon/cross.jpg" alt=""> Responsive</p>
            <p><img src="assets/images/cross right icon/right.jpg" alt="">Responsive</p>
            <p> <img src="assets/images/cross right icon/cross.jpg" alt=""> Responsive</p>
            <p><img src="assets/images/cross right icon/right.jpg" alt="">Responsive</p>
            <p> <img src="assets/images/cross right icon/cross.jpg" alt=""> Responsive</p>
            <p><img src="assets/images/cross right icon/right.jpg" alt="">Responsive</p>
            <p> <img src="assets/images/cross right icon/cross.jpg" alt=""> Responsive</p>
            <p><img src="assets/images/cross right icon/right.jpg" alt="">Responsive</p>
            <p> <img src="assets/images/cross right icon/cross.jpg" alt=""> Responsive</p>
            <p><img src="assets/images/cross right icon/right.jpg" alt="">Responsive</p>
            <p> <img src="assets/images/cross right icon/cross.jpg" alt=""> Responsive</p>
            <p><img src="assets/images/cross right icon/right.jpg" alt="">Responsive</p>
            <div class="service-btn btn-box">
                <a href="#" class="btn ">Buy Now</a>
            </div>
        </div>
        <div class="pricing-box">
        <div class="box-img">
                <img src="assets/images/cross right icon/silver.jpg" alt="">
            </div>
            <h3>Silver</h3>
            <h2>Price <span>113.54/-</span></h2>
            <p> <img src="assets/images/cross right icon/cross.jpg" alt=""> Responsive</p>
            <p><img src="assets/images/cross right icon/right.jpg" alt="">Responsive</p>
            <p> <img src="assets/images/cross right icon/cross.jpg" alt=""> Responsive</p>
            <p><img src="assets/images/cross right icon/right.jpg" alt="">Responsive</p>
            <p> <img src="assets/images/cross right icon/cross.jpg" alt=""> Responsive</p>
            <p><img src="assets/images/cross right icon/right.jpg" alt="">Responsive</p>
            <p> <img src="assets/images/cross right icon/cross.jpg" alt=""> Responsive</p>
            <p><img src="assets/images/cross right icon/right.jpg" alt="">Responsive</p>
            <p> <img src="assets/images/cross right icon/cross.jpg" alt=""> Responsive</p>
            <p><img src="assets/images/cross right icon/right.jpg" alt="">Responsive</p>
            <p> <img src="assets/images/cross right icon/cross.jpg" alt=""> Responsive</p>
            <p><img src="assets/images/cross right icon/right.jpg" alt="">Responsive</p>
            <div class="service-btn btn-box">
                <a href="#" class="btn">Buy Now</a>
            </div>
        </div>
        <div class="pricing-box">
            <div class="box-img">
                <img src="assets/images/cross right icon/gold.jpg" alt="">
            </div>
            <h3>Gold</h3>
            <h2>Price <span>69.87/-</span></h2>
            <p> <img src="assets/images/cross right icon/cross.jpg" alt=""> Responsive</p>
            <p><img src="assets/images/cross right icon/right.jpg" alt="">Responsive</p>
            <p> <img src="assets/images/cross right icon/cross.jpg" alt=""> Responsive</p>
            <p><img src="assets/images/cross right icon/right.jpg" alt="">Responsive</p>
            <p> <img src="assets/images/cross right icon/cross.jpg" alt=""> Responsive</p>
            <p><img src="assets/images/cross right icon/right.jpg" alt="">Responsive</p>
            <p> <img src="assets/images/cross right icon/cross.jpg" alt=""> Responsive</p>
            <p><img src="assets/images/cross right icon/right.jpg" alt="">Responsive</p>
            <p> <img src="assets/images/cross right icon/cross.jpg" alt=""> Responsive</p>
            <p><img src="assets/images/cross right icon/right.jpg" alt="">Responsive</p>
            <p> <img src="assets/images/cross right icon/cross.jpg" alt=""> Responsive</p>
            <p><img src="assets/images/cross right icon/right.jpg" alt="">Responsive</p>
            <div class="pricing-btn btn-box">
                <a href="#" class="btn">Buy Now</a>
            </div>
        </div>
    </div>
</section>

<section id="support" class="support">
    <div class="main-text">
        <span>LIFE TIME SUPPORT</span>
        <h3>GET SUPPORT EMMIDIATELY </h3>
    </div>
    <div class="section-support">
        <div class="support-boxing">
            <div class="support-box">
                <h2>24 Horse Support </h2>
                <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Atque, fuga animi. Cupiditate dignissimos eligendi architecto tempora cumque voluptatem nostrum, alias corrupti autem libero, ipsa nihil.</p>
            </div>
            <div class="support-box">
                <h2>Have any question </h2>
                <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Atque, fuga animi. Cupiditate dignissimos eligendi architecto tempora cumque voluptatem nostrum, alias corrupti autem libero, ipsa nihil.</p>
            </div>
        </div>
        <div class="support-boxing">
            <div class="support-box">
                <h2>Get smart idea about webstie </h2>
                <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Atque, fuga animi. Cupiditate dignissimos eligendi architecto tempora cumque voluptatem nostrum, alias corrupti autem libero, ipsa nihil.</p>
            </div>
            <div class="support-box">
                <h2>Collaboration with us </h2>
                <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Atque, fuga animi. Cupiditate dignissimos eligendi architecto tempora cumque voluptatem nostrum, alias corrupti autem libero, ipsa nihil.</p>
            </div>
        </div>
    </div>

</section>