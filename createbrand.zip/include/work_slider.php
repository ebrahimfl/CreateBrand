<link rel="stylesheet" href="assets/css/service-details.css">
<div class="container">
    <div id="service-details" class="our-work">
            <h2 style='margin-top:80px' class='an' data-an='fade-up'>Enjoy Our Amazing Projects</h2>
            <div class="work_rows">
                <div class="card an" data-work="Websaite Design" data-an='zoom-in'>
                    <img src="<?php base_url('assets/images/1-1.png')?>" alt="" class="card_img">
                    <div class="hover_effect">
                        <h4>Website Design</h4>
                        <a class="img" href='#' target="_blank">
                            <img src="<?php base_url('assets/icons/right-arrow.png') ?>" alt="">
                        </a>
                    </div>
                </div>
                <div class="card an" data-work="Websaite Design" data-an='zoom-in'>
                    <img src="<?php base_url('assets/images/1.jpg')?>" alt="" class="card_img">
                    <div class="hover_effect">
                        <h4>Website Design</h4>
                        <a class="img" href='#' target="_blank">
                            <img src="<?php base_url('assets/icons/right-arrow.png')?>" alt="">
                        </a>
                    </div>
                </div>
                <div class="card an" data-work="Websaite Design" data-an='zoom-in'>
                    <img src="<?php base_url('assets/images/card-img.png')?>" alt="" class="card_img">
                    <div class="hover_effect">
                        <h4>Website Design</h4>
                        <a class="img" href='#' target="_blank">
                            <img src="<?php base_url('assets/icons/right-arrow.png')?>" alt="">
                        </a>
                    </div>
                </div>
                <div class="card an" data-work="Websaite Design" data-an='zoom-in'>
                    <img src="<?php base_url('assets/images/2-1.png')?>" alt="" class="card_img">
                    <div class="hover_effect">
                        <h4>Website Design</h4>
                        <a class="img" href='#' target="_blank">
                            <img src="<?php base_url('assets/icons/right-arrow.png')?>" alt="">
                        </a>
                    </div>
                </div>
                <div class="card an" data-work="Websaite Design" data-an='zoom-in'>
                    <img src="<?php base_url('assets/images/2-1.png')?>" alt="" class="card_img">
                    <div class="hover_effect">
                        <h4>Website Design</h4>
                        <a class="img" href='#' target="_blank">
                            <img src="<?php base_url('assets/icons/right-arrow.png')?>" alt="">
                        </a>
                    </div>
                </div>
                <div class="card an" data-work="Websaite Design" data-an='zoom-in'>
                    <img src="<?php base_url('assets/images/2-1.png')?>" alt="" class="card_img">
                    <div class="hover_effect">
                        <h4>Website Design</h4>
                        <a class="img" href='#' target="_blank">
                            <img src="<?php base_url('assets/icons/right-arrow.png')?>" alt="">
                        </a>
                    </div>
                </div>
                <div class="card an" data-work="Websaite Design" data-an='zoom-in'>
                    <img src="<?php base_url('assets/images/2-1.png')?>" alt="" class="card_img">
                    <div class="hover_effect">
                        <h4>Website Design</h4>
                        <a class="img" href='#' target="_blank">
                            <img src="<?php base_url('assets/icons/right-arrow.png')?>" alt="">
                        </a>
                    </div>
                </div>
                
            </div>
        </div>
</div>