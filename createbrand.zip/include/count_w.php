

<link rel="stylesheet" href="assets/css/about.css">
<section id="about" class="container">
    <div class="counter_wrapper">
        <div class="card an" data-an='fade-right'>
            <h4 data-counter-value='2'>0<span>+</span></h4>
            <h5>YEARS IN BUSINESS</h5>
        </div>
        <div class="card an" data-an='fade-down'>
            <h4 data-counter-value='100'>0<span>+</span></h4>
            <h5>FINISHED PROJECTS</h5>
        </div>
        <div class="card an" data-an='fade-up'>
            <h4 data-counter-value='700'>0<span>+</span></h4>
            <h5>CLIENTS</h5>
        </div>
        <div class="card an" data-an='fade-left'>
            <h4 data-counter-value='800'>0<span>+</span></h4>
            <h5>REVIEWS</h5>
        </div>
    </div>
</section>