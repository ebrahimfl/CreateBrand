<?php require_once "include/header.php"; ?>
<link rel="stylesheet" href="assets/css/about.css">
<?php require_once "include/headerM.php"; ?>


    <!-- <h1>About us</h1> -->
    <div class="container">
        

    <?php require_once "include/slider.php"; ?>
    <?php require_once "include/about.php"; ?>
    <?php require_once "include/service_slider.php"; ?>
<div style='margin-top:80px'>
        
        <?php require_once "include/count_w.php"; ?>
    </div>



<?php require_once "include/footer.php"; ?>