<?php require_once "include/header.php"; ?>

<?php require_once "include/headerM.php"; ?>

<section style="width:100%;padding:20px;"> 
    <img src="assets/images/6333073-ai.png" alt=""style="width:100%;max-height:700px">
</section>

<?php require_once 'include/footer.php' ?>