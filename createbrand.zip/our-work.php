<?php require_once "include/header.php"; ?>
<link rel="stylesheet" href="assets/css/our-work.css">
<?php require_once "include/headerM.php"; ?>

<section id="our-work">
    <div class="container">
        <div class="header-menu an" data-an='fade-left'>
            <ul>
                <li class='active' data-work="All">All</li>
                <li data-work="Websaite Design">Websaite Design</li>
                <li data-work="Web Development">Websaite Development</li>
                <li data-work="Full Stack Development">Full Stack Development</li>
                <li data-work="SEO">SEO</li>
            </ul>
        </div>
        <?php require_once "include/ourproject.php"; ?>
</section>

<?php require_once "include/footer.php"; ?>