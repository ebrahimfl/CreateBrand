  // JavaScript to toggle the dropdown content
  document.addEventListener("DOMContentLoaded", function() {
    var dropdown = document.querySelector('.dropdown');
    
    dropdown.addEventListener('click', function() {
      var dropdownContent = this.querySelector('.dropdown-content');
      dropdownContent.style.display = (dropdownContent.style.display === 'block') ? 'none' : 'block';
    });
  });