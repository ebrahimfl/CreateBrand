const toggle = document.getElementById('toggle');
const body = document.querySelector('body');

toggle.addEventListener('click', function(){
    this.classList.toggle('bi-moon');
    if(this.classList.toggle('bi-brightness-high')){
      body.style.background = '#e3e6e6';
      body.style.color = 'black';
      body.style.transition = '2s';
    }else{
      body.style.background = 'black';
      body.style.color = '#e3e6e6';
      body.style.transition = '2s';
    }
})
console.log(ami)